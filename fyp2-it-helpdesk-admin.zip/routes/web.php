<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\TicketController;

// ---------------------------
// Root
// ---------------------------
Route::get('/', function() {
    return redirect()->route('login');
});

// ---------------------------
// Signup & User Dashboard
// ---------------------------
Route::get('/signup', function () {
    return view('signup'); // resources/views/signup.blade.php
});

Route::get('/dashboard', function () {
    return view('dashboard'); // resources/views/dashboard.blade.php
});

// ---------------------------
// Tickets
// ---------------------------
Route::post('/tickets', [TicketController::class, 'store']);

// ---------------------------
// Admin Dashboard (Firebase-based)
// ---------------------------
Route::get('/admin/dashboard', function() {
    return view('admin.dashboard'); // Firebase dashboard HTML
})->name('admin.dashboard');

// ---------------------------
// Admin Ticket Chat — Firebase-based
// ---------------------------
Route::get('/admin/tickets/{id}/chat', [AdminController::class, 'ticketChat'])
    ->name('admin.ticket.chat');

// ---------------------------
// Laravel Auth for Admin (optional)
// ---------------------------
Route::get('/login', [AdminController::class, 'showLogin'])->name('login');
Route::post('/login', [AdminController::class, 'login'])->name('login.post');
Route::post('/logout', [AdminController::class, 'logout'])->name('logout');
