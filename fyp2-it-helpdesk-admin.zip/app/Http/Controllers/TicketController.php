<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Ticket;
use App\Models\User;

class TicketController extends Controller
{
    /**
     * Store a newly created ticket and auto-assign admin.
     */
    public function store(Request $request)
    {
        // 1. Validate request
        $request->validate([
            'title' => 'required|string|max:255',
            'description' => 'required|string',
        ]);

        // 2. Find admin (user) with least assigned tickets
        $admin = User::withCount('tickets')
                     ->orderBy('tickets_count', 'asc')
                     ->first();

        // 3. Create ticket
        $ticket = Ticket::create([
            'title' => $request->title,
            'description' => $request->description,
            'assigned_admin_id' => $admin ? $admin->id : null,
        ]);

        // 4. Response (used by user-side JS)
        return response()->json([
            'message' => 'Ticket submitted successfully',
            'assigned_admin' => $admin ? $admin->name : 'Not assigned',
        ]);
    }
}
