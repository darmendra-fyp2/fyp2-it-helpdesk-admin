<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AdminController extends Controller
{
    /**
     * Show the admin login page
     */
    public function showLogin()
    {
        return view('admin.login');
    }

    /**
     * Process admin login
     */
    public function login(Request $request)
    {
        $credentials = $request->only('email', 'password');

        if (Auth::attempt($credentials)) {
            $request->session()->regenerate();
            return redirect()->route('admin.dashboard');
        }

        return back()->withErrors(['email' => 'Invalid credentials']);
    }

    /**
     * Show the admin dashboard (HTML/Firebase)
     */
    public function dashboard()
    {
        return view('admin.dashboard'); // Your HTML/Firebase dashboard
    }

    /**
     * Admin logout
     */
    public function logout(Request $request)
    {
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect()->route('login');
    }

    /**
     * Show ticket chat page (Firebase-based)
     * Passes ticketId to Blade
     */
    public function ticketChat($id)
    {
        return view('admin.ticket_chat', [
            'ticketId' => $id,
            'adminEmail' => auth()->user()->email ?? 'admin@example.com'
        ]);
    }
}
