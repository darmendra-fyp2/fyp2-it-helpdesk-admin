<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>IT Helpdesk - Login</title>

<!-- CSS -->
<link rel="stylesheet" href="{{ asset('css/login.css') }}">

</head>
<body>

<div class="container">
    <h2>IT Helpdesk</h2>

    <!-- Error message from JS -->
    <div id="errorMsg"></div>

    <!-- Login Form -->
    <form id="loginForm">
        <input type="email" name="email" placeholder="Email" required>
        <input type="password" name="password" placeholder="Password" required>
        <button type="submit">Login</button>
    </form>

    <div class="toggle-link" onclick="window.location.href='/signup'">
        Don’t have an account? Sign up
    </div>
</div>

<!-- Firebase SDK -->
<script src="https://www.gstatic.com/firebasejs/9.23.0/firebase-app-compat.js"></script>
<script src="https://www.gstatic.com/firebasejs/9.23.0/firebase-auth-compat.js"></script>
<script src="https://www.gstatic.com/firebasejs/9.23.0/firebase-firestore-compat.js"></script>

<!-- Firebase Config -->
<script>
const firebaseConfig = {
  apiKey: "AIzaSyBOaHzIMdXZHOfgDS56sKKL6NLRT41dBmM",
  authDomain: "it-helpdesk-fyp2.firebaseapp.com",
  projectId: "it-helpdesk-fyp2",
  storageBucket: "it-helpdesk-fyp2.firebasestorage.app",
  messagingSenderId: "168621686870",
  appId: "1:168621686870:web:a3cd6fd0c36b60c0adbbf7",
  measurementId: "G-MVE0EDPWTT"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);
</script>

<!-- Login Logic (Firebase Authentication + Firestore for roles) -->
<script src="{{ asset('js/login.js') }}"></script>

</body>
</html>
