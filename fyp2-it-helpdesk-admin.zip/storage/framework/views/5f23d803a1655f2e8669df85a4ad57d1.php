<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Admin Chat – IT Helpdesk</title>
    
    <!-- Fonts & Icons -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"/>

    <style>
        :root {
            --primary: #6366f1;
            --primary-dark: #4f46e5;
            --primary-glow: #818cf8;
            --bg-dark: #0f172a;
            --bg-panel: rgba(30, 41, 59, 0.6);
            --glass-bg: rgba(30, 41, 59, 0.45);
            --glass-border: rgba(99, 102, 241, 0.3);
            --text-light: #f1f5f9;
            --text-muted: #94a3b8;
            --border: #334155;
            --user-bg: rgba(45, 55, 72, 0.7);
            --admin-bg: rgba(67, 56, 202, 0.6);
            --shadow: 0 8px 32px rgba(0, 0, 0, 0.5);
        }

        * { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #0f172a 0%, #1e1b4b 100%);
            color: var(--text-light);
            height: 100vh;
            overflow: hidden;
            position: relative;
        }

        body::before {
            content: "";
            position: fixed;
            inset: 0;
            background: rgba(0,0,0,0.4);
            z-index: -2;
        }

        #particles {
            position: fixed;
            top: 0; left: 0;
            width: 100%;
            height: 100%;
            pointer-events: none;
            z-index: -1;
        }

        .chat-dashboard {
            position: relative;
            z-index: 1;
            display: flex;
            flex-direction: column;
            max-width: 1000px;
            margin: 1.5rem auto;
            height: calc(100vh - 3rem);
            padding: 1rem;
            backdrop-filter: blur(12px);
            background: var(--glass-bg);
            border: 1px solid var(--glass-border);
            border-radius: 24px;
            box-shadow: var(--shadow);
            overflow: hidden;
        }

        .chat-header {
            background: rgba(30, 41, 59, 0.6);
            backdrop-filter: blur(10px);
            border-bottom: 1px solid var(--glass-border);
            padding: 1.25rem 1.8rem;
            border-radius: 24px 24px 0 0;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 4px 20px rgba(0,0,0,0.3);
        }

        .header-info h2 {
            font-size: 1.6rem;
            font-weight: 700;
            margin-bottom: 0.25rem;
        }

        .header-info p {
            font-size: 0.9rem;
            color: var(--text-muted);
        }

        .settings-btn {
            background: transparent;
            border: none;
            color: var(--text-muted);
            font-size: 1.4rem;
            cursor: pointer;
            padding: 0.5rem;
            border-radius: 50%;
            transition: all 0.3s;
        }

        .settings-btn:hover {
            color: var(--primary-glow);
            background: rgba(99, 102, 241, 0.2);
            transform: rotate(30deg);
        }

        .chat-messages {
            flex: 1;
            padding: 1.8rem;
            overflow-y: auto;
            display: flex;
            flex-direction: column;
            gap: 1.2rem;
            scrollbar-width: thin;
        }

        .chat-messages::-webkit-scrollbar {
            width: 6px;
        }

        .chat-messages::-webkit-scrollbar-thumb {
            background: rgba(99, 102, 241, 0.4);
            border-radius: 3px;
        }

        .message {
            max-width: 80%;
            padding: 1rem 1.3rem;
            border-radius: 18px;
            line-height: 1.5;
            font-size: 1rem;
            position: relative;
            backdrop-filter: blur(8px);
            box-shadow: 0 4px 15px rgba(0,0,0,0.3);
            border: 1px solid rgba(255,255,255,0.08);
        }

        .message.user {
            background: var(--user-bg);
            align-self: flex-start;
            border-bottom-left-radius: 6px;
            border: 1px solid rgba(99, 102, 241, 0.4);
        }

        .message.admin {
            background: var(--admin-bg);
            align-self: flex-end;
            border-bottom-right-radius: 6px;
            border: 1px solid rgba(99, 102, 241, 0.4);
            color: white;
        }

        .message .sender {
            font-size: 0.8rem;
            opacity: 0.8;
            margin-bottom: 0.4rem;
            display: block;
            font-weight: 500;
        }

        .message .time {
            font-size: 0.75rem;
            opacity: 0.6;
            margin-top: 0.5rem;
            display: block;
            text-align: right;
        }

        .message img {
            max-width: 100%;
            border-radius: 12px;
            margin-top: 0.8rem;
            cursor: pointer;
            display: block;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(0,0,0,0.4);
        }

        .message img:hover {
            transform: scale(1.04);
            box-shadow: 0 8px 25px rgba(99, 102, 241, 0.5);
        }

        .chat-input-container {
            background: rgba(30,41,59,0.6);
            backdrop-filter: blur(12px);
            border-top: 1px solid var(--glass-border);
            padding: 1.2rem 1.8rem;
            border-radius: 0 0 24px 24px;
            box-shadow: 0 -4px 20px rgba(0,0,0,0.3);
        }

        .chat-input-form {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .chat-input-form input[type="text"] {
            flex: 1;
            padding: 1rem 1.4rem;
            border: 1px solid var(--glass-border);
            border-radius: 16px;
            background: rgba(30,41,59,0.7);
            color: var(--text-light);
            font-size: 1rem;
            outline: none;
            transition: all 0.3s ease;
            box-shadow: inset 0 2px 10px rgba(0,0,0,0.3);
        }

        .chat-input-form input[type="text"]:focus {
            border-color: var(--primary-glow);
            box-shadow: 0 0 0 4px rgba(99, 102, 241, 0.3);
        }

        .attachment-btn {
            background: transparent;
            border: none;
            color: var(--text-muted);
            font-size: 1.5rem;
            cursor: pointer;
            padding: 0.8rem;
            border-radius: 50%;
            transition: all 0.3s;
        }

        .attachment-btn:hover {
            color: var(--primary);
            background: rgba(99, 102, 241, 0.2);
            transform: rotate(15deg);
        }

        .chat-input-form button[type="submit"] {
            padding: 1rem 1.6rem;
            background: linear-gradient(90deg, #6366f1, #818cf8);
            color: white;
            border: none;
            border-radius: 16px;
            cursor: pointer;
            font-weight: 600;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            gap: 0.6rem;
            box-shadow: 0 4px 15px rgba(99, 102, 241, 0.5);
        }

        .chat-input-form button[type="submit"]:hover {
            transform: translateY(-2px) scale(1.05);
            box-shadow: 0 8px 25px rgba(99, 102, 241, 0.6);
        }

        .preview-container {
            margin-top: 0.8rem;
            display: flex;
            align-items: center;
            gap: 1rem;
            flex-wrap: wrap;
        }

        .preview-container img {
            max-width: 140px;
            max-height: 140px;
            border-radius: 12px;
            border: 2px solid var(--glass-border);
            box-shadow: 0 4px 15px rgba(0,0,0,0.4);
        }

        .preview-container button {
            background: rgba(239,68,68,0.8);
            color: white;
            border: none;
            padding: 0.5rem 1rem;
            border-radius: 10px;
            cursor: pointer;
            backdrop-filter: blur(5px);
        }

        /* Image Modal */
        #imageModal {
            display: none;
            position: fixed;
            top: 0; left: 0;
            width: 100%; height: 100%;
            background: rgba(0,0,0,0.92);
            backdrop-filter: blur(8px);
            z-index: 1000;
            justify-content: center;
            align-items: center;
        }
        #modalImage {
            max-width: 92%;
            max-height: 92vh;
            border-radius: 16px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.8);
            border: 2px solid rgba(99, 102, 241, 0.4);
        }
        #closeModal {
            position: absolute;
            top: 30px; right: 40px;
            color: white;
            font-size: 48px;
            cursor: pointer;
            text-shadow: 0 0 10px rgba(0,0,0,0.8);
            transition: all 0.3s;
        }
        #closeModal:hover {
            transform: scale(1.2);
            color: var(--primary-glow);
        }

        /* Wallpaper Modal */
        #wallpaperModal {
            display: none;
            position: fixed;
            top: 0; left: 0;
            width: 100%; height: 100%;
            background: rgba(0,0,0,0.85);
            backdrop-filter: blur(10px);
            z-index: 1000;
            justify-content: center;
            align-items: center;
        }

        .wallpaper-content {
            background: rgba(30,41,59,0.8);
            backdrop-filter: blur(15px);
            border: 1px solid var(--glass-border);
            border-radius: 20px;
            padding: 2rem;
            max-width: 700px;
            width: 90%;
            box-shadow: 0 20px 60px rgba(0,0,0,0.7);
            color: var(--text-light);
            text-align: center;
        }

        .wallpaper-content h3 {
            margin-bottom: 1.5rem;
            font-size: 1.6rem;
            color: var(--primary-glow);
        }

        .wallpaper-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));
            gap: 1rem;
            margin: 1.5rem 0;
        }

        .wallpaper-option {
            width: 100%;
            height: 140px;
            border-radius: 12px;
            background-size: cover;
            background-position: center;
            cursor: pointer;
            transition: all 0.3s;
            border: 3px solid transparent;
            box-shadow: 0 4px 15px rgba(0,0,0,0.4);
        }

        .wallpaper-option:hover,
        .wallpaper-option.selected {
            border-color: var(--primary-glow);
            transform: scale(1.08);
            box-shadow: 0 8px 25px rgba(99, 102, 241, 0.6);
        }

        .wallpaper-option.upload {
            background: rgba(99, 102, 241, 0.2);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.2rem;
            color: var(--primary-glow);
        }

        .wallpaper-content button {
            background: linear-gradient(90deg, #6366f1, #818cf8);
            color: white;
            border: none;
            padding: 0.8rem 1.5rem;
            border-radius: 12px;
            cursor: pointer;
            font-weight: 600;
            margin-top: 1rem;
        }
    </style>
</head>
<body id="body">

    <!-- Animated background particles -->
    <canvas id="particles"></canvas>

    <div class="chat-dashboard">
        <div class="chat-header">
            <div class="header-info">
                <h2>Admin Chat</h2>
                <p>Ticket ID: <strong><?php echo e($ticketId); ?></strong></p>
                <p>Admin: <strong><?php echo e($adminEmail ?? 'admin@example.com'); ?></strong></p>
            </div>
            <button class="settings-btn" id="openWallpaperBtn" title="Change Background">
                <i class="fas fa-palette"></i>
            </button>
        </div>

        <div class="chat-messages" id="chatMessages">
            <!-- Messages rendered here -->
        </div>

        <div class="chat-input-container">
            <form class="chat-input-form" id="chatForm">
                <input type="text" id="messageInput" placeholder="Type your message..." autocomplete="off" />
                <label for="fileInput" class="attachment-btn" title="Attach photo">
                    <i class="fas fa-paperclip"></i>
                </label>
                <input type="file" id="fileInput" accept="image/*" style="display: none;" />
                <button type="submit" id="sendBtn">
                    <i class="fas fa-paper-plane"></i>
                    Send
                </button>
            </form>

            <div class="preview-container" id="previewContainer"></div>
        </div>
    </div>

    <!-- Image Modal -->
    <div id="imageModal">
        <span id="closeModal">&times;</span>
        <img id="modalImage" alt="Full size image">
    </div>

    <!-- Wallpaper Change Modal -->
    <div id="wallpaperModal">
        <div class="wallpaper-content">
            <h3>Choose Your Background</h3>
            <div class="wallpaper-grid">
                <div class="wallpaper-option" data-bg="https://images.unsplash.com/photo-1557683316-973673baf926?w=1920&q=80" style="background-image:url('https://images.unsplash.com/photo-1557683316-973673baf926?w=400&q=80');" title="Cosmic Nebula"></div>
                <div class="wallpaper-option" data-bg="https://images.unsplash.com/photo-1553356084-58ef4a67b2a7?w=1920&q=80" style="background-image:url('https://images.unsplash.com/photo-1553356084-58ef4a67b2a7?w=400&q=80');" title="Aurora Glow"></div>
                <div class="wallpaper-option" data-bg="https://images.unsplash.com/photo-1519681393784-d120267933ba?w=1920&q=80" style="background-image:url('https://images.unsplash.com/photo-1519681393784-d120267933ba?w=400&q=80');" title="Starry Night"></div>
                <div class="wallpaper-option" data-bg="https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=1920&q=80" style="background-image:url('https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=400&q=80');" title="Mountain Mist"></div>
                <div class="wallpaper-option upload" id="uploadWallpaper">
                    <i class="fas fa-upload"></i> Upload Your Own
                </div>
            </div>
            <input type="file" id="wallpaperInput" accept="image/*" style="display:none;">
            <button id="closeWallpaperBtn">Close</button>
        </div>
    </div>

    <!-- Firebase Scripts -->
    <script src="https://www.gstatic.com/firebasejs/9.23.0/firebase-app-compat.js"></script>
    <script src="https://www.gstatic.com/firebasejs/9.23.0/firebase-auth-compat.js"></script>
    <script src="https://www.gstatic.com/firebasejs/9.23.0/firebase-firestore-compat.js"></script>

    <script>
        // === Particles Animation ===
        const canvas = document.getElementById('particles');
        const ctx = canvas.getContext('2d');
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;

        window.addEventListener('resize', () => {
            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;
        });

        let particles = [];
        const particleCount = 80;

        class Particle {
            constructor() {
                this.x = Math.random() * canvas.width;
                this.y = Math.random() * canvas.height;
                this.size = Math.random() * 3 + 1;
                this.speedX = Math.random() * 1 - 0.5;
                this.speedY = Math.random() * 1 - 0.5;
                this.opacity = Math.random() * 0.5 + 0.2;
            }
            update() {
                this.x += this.speedX;
                this.y += this.speedY;
                if (this.x > canvas.width || this.x < 0) this.speedX *= -1;
                if (this.y > canvas.height || this.y < 0) this.speedY *= -1;
            }
            draw() {
                ctx.fillStyle = `rgba(99, 102, 241, ${this.opacity})`;
                ctx.beginPath();
                ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
                ctx.fill();
            }
        }

        function initParticles() {
            particles = [];
            for (let i = 0; i < particleCount; i++) {
                particles.push(new Particle());
            }
        }

        function animateParticles() {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            particles.forEach(p => {
                p.update();
                p.draw();
            });
            requestAnimationFrame(animateParticles);
        }

        initParticles();
        animateParticles();

        // === Wallpaper Changer ===
        const body = document.getElementById('body');
        const wallpaperModal = document.getElementById('wallpaperModal');
        const openWallpaperBtn = document.getElementById('openWallpaperBtn');
        const closeWallpaperBtn = document.getElementById('closeWallpaperBtn');
        const wallpaperInput = document.getElementById('wallpaperInput');

        openWallpaperBtn.addEventListener('click', () => {
            wallpaperModal.style.display = 'flex';
        });

        closeWallpaperBtn.addEventListener('click', () => {
            wallpaperModal.style.display = 'none';
        });

        wallpaperModal.addEventListener('click', (e) => {
            if (e.target === wallpaperModal) {
                wallpaperModal.style.display = 'none';
            }
        });

        // Predefined backgrounds
        document.querySelectorAll('.wallpaper-option:not(.upload)').forEach(opt => {
            opt.addEventListener('click', () => {
                const bgUrl = opt.getAttribute('data-bg');
                body.style.backgroundImage = `url('${bgUrl}')`;
                document.querySelectorAll('.wallpaper-option').forEach(el => el.classList.remove('selected'));
                opt.classList.add('selected');
                wallpaperModal.style.display = 'none';
            });
        });

        // Custom upload
        document.getElementById('uploadWallpaper').addEventListener('click', () => {
            wallpaperInput.click();
        });

        wallpaperInput.addEventListener('change', (e) => {
            if (e.target.files && e.target.files[0]) {
                const file = e.target.files[0];
                const reader = new FileReader();
                reader.onload = (event) => {
                    body.style.backgroundImage = `url('${event.target.result}')`;
                    wallpaperModal.style.display = 'none';
                };
                reader.readAsDataURL(file);
            }
        });

        // === Firebase & Chat Logic ===
        const firebaseConfig = {
            apiKey: "AIzaSyBOaHzIMdXZHOfgDS56sKKL6NLRT41dBmM",
            authDomain: "it-helpdesk-fyp2.firebaseapp.com",
            projectId: "it-helpdesk-fyp2",
            storageBucket: "it-helpdesk-fyp2.firebasestorage.app",
            messagingSenderId: "168621686870",
            appId: "1:168621686870:web:a3cd6fd0c36b60c0adbbf7"
        };
        firebase.initializeApp(firebaseConfig);
        const auth = firebase.auth();
        const db = firebase.firestore();

        // DOM Elements
        const ticketId = "<?php echo e($ticketId); ?>";
        const chatMessages = document.getElementById("chatMessages");
        const messageInput = document.getElementById("messageInput");
        const sendBtn = document.getElementById("sendBtn");
        const fileInput = document.getElementById("fileInput");
        const previewContainer = document.getElementById("previewContainer");
        const chatForm = document.getElementById("chatForm");

        let selectedFile = null;
        let previewURL = null;

        // Auth check
        auth.onAuthStateChanged(user => {
            if (!user) window.location = "/login";
        });

        // Format timestamp
        function formatTime(timestamp) {
            if (!timestamp) return "";
            const date = timestamp.toDate();
            return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        }

        // Convert file to Base64
        function fileToBase64(file) {
            return new Promise((resolve, reject) => {
                const reader = new FileReader();
                reader.readAsDataURL(file);
                reader.onload = () => resolve(reader.result);
                reader.onerror = error => reject(error);
            });
        }

        // Load messages
        db.collection("tickets").doc(ticketId).collection("messages")
            .orderBy("createdAt", "asc")
            .onSnapshot(snapshot => {
                chatMessages.innerHTML = "";
                snapshot.forEach(doc => {
                    const msg = doc.data();
                    const isAdmin = msg.sender === "admin";

                    const div = document.createElement("div");
                    div.classList.add("message");
                    div.classList.add(isAdmin ? "admin" : "user");

                    let content = `<span class="sender">${msg.sender === "admin" ? "You" : "User"}</span>`;
                    content += msg.text ? `<div>${msg.text}</div>` : "";

                    if (msg.imageBase64) {
                        content += `<img src="${msg.imageBase64}" alt="Attachment" class="chat-image" data-full="${msg.imageBase64}">`;
                    }

                    content += `<span class="time">${formatTime(msg.createdAt)}</span>`;
                    div.innerHTML = content;

                    chatMessages.appendChild(div);
                });
                chatMessages.scrollTop = chatMessages.scrollHeight;
            });

        // Handle file selection
        fileInput.addEventListener("change", async (e) => {
            if (e.target.files && e.target.files[0]) {
                selectedFile = e.target.files[0];
                previewURL = URL.createObjectURL(selectedFile);

                previewContainer.innerHTML = `
                    <img src="${previewURL}" alt="Preview" />
                    <button type="button" onclick="clearPreview()">Remove</button>
                `;
            }
        });

        function clearPreview() {
            selectedFile = null;
            previewURL = null;
            previewContainer.innerHTML = "";
            fileInput.value = "";
        }

        // Send message (text + optional base64 image)
        async function sendMessage() {
            const text = messageInput.value.trim();

            if (!text && !selectedFile) return;

            let imageBase64 = null;

            if (selectedFile) {
                try {
                    imageBase64 = await fileToBase64(selectedFile);
                    if (imageBase64.length > 1000000) { // ~750KB base64
                        if (!confirm("Image is quite large. Firestore may reject it. Continue?")) {
                            return;
                        }
                    }
                } catch (error) {
                    console.error("Base64 conversion failed:", error);
                    alert("Failed to process image.");
                    return;
                }
            }

            db.collection("tickets").doc(ticketId).collection("messages").add({
                sender: "admin",
                text: text || "",
                imageBase64: imageBase64 || null,
                createdAt: firebase.firestore.FieldValue.serverTimestamp()
            }).then(() => {
                messageInput.value = "";
                clearPreview();
                messageInput.focus();
            }).catch(error => {
                console.error("Message send failed:", error);
                alert("Failed to send message: " + error.message);
            });
        }

        sendBtn.addEventListener("click", (e) => {
            e.preventDefault();
            sendMessage();
        });

        messageInput.addEventListener("keypress", (e) => {
            if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                sendMessage();
            }
        });

        chatForm.addEventListener("submit", (e) => {
            e.preventDefault();
            sendMessage();
        });

        // === Image Modal Functionality ===
        const modal = document.getElementById("imageModal");
        const modalImg = document.getElementById("modalImage");
        const closeModal = document.getElementById("closeModal");

        // Open modal when clicking an image
        chatMessages.addEventListener("click", (e) => {
            if (e.target.classList.contains("chat-image")) {
                const src = e.target.getAttribute("data-full") || e.target.src;
                modalImg.src = src;
                modal.style.display = "flex";
            }
        });

        // Close modal
        closeModal.addEventListener("click", () => {
            modal.style.display = "none";
        });

        // Close modal when clicking outside the image
        modal.addEventListener("click", (e) => {
            if (e.target === modal || e.target === closeModal) {
                modal.style.display = "none";
            }
        });
    </script>

</body>
</html><?php /**PATH C:\Users\darme\FYP2_Admin_laravel_side\resources\views/admin/ticket_chat.blade.php ENDPATH**/ ?>