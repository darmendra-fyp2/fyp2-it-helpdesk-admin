<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>IT Helpdesk - Login / Signup</title>

<!-- Your CSS -->
<link rel="stylesheet" href="<?php echo e(asset('css/login.css')); ?>">
</head>
<body>

<div class="container">
    <h2>IT Helpdesk</h2>

    <!-- Display errors from Laravel -->
    <?php if($errors->any()): ?>
        <div id="errorMsg"><?php echo e($errors->first()); ?></div>
    <?php endif; ?>

    <!-- ===== Login Form ===== -->
    <form method="POST" action="<?php echo e(route('login.post')); ?>" id="loginForm">
        <?php echo csrf_field(); ?>
        <input type="email" name="email" placeholder="Email" required>
        <input type="password" name="password" placeholder="Password" required>
        <button type="submit">Login</button>
        <!-- Signup toggle removed; optional if you want only admin login -->
    </form>
</div>

<!-- Firebase JS (optional for login, keep if needed) -->
<script src="https://www.gstatic.com/firebasejs/9.23.0/firebase-app-compat.js"></script>
<script src="https://www.gstatic.com/firebasejs/9.23.0/firebase-auth-compat.js"></script>
<script src="https://www.gstatic.com/firebasejs/9.23.0/firebase-firestore-compat.js"></script>

<!-- Your JS -->
<script src="<?php echo e(asset('js/login.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\Users\darme\FYP2_User_laravel_side\resources\views/admin/login.blade.php ENDPATH**/ ?>