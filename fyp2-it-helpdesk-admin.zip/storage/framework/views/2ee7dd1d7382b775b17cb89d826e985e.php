<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Signup - IT Helpdesk</title>

<link rel="stylesheet" href="<?php echo e(asset('css/login.css')); ?>">
</head>
<body>

<div class="container">
    <h2>Create Account</h2>

    <div id="errorMsg"></div>

    <form id="signupForm">
        <input type="text" name="name" placeholder="Full Name" required>
        <input type="email" name="email" placeholder="Email" required>
        <input type="password" name="password" placeholder="Password (min 6)" required>
        <button type="submit">Sign Up</button>
    </form>

    <div class="toggle-link" onclick="window.location.href='/login'">
        Already have an account? Login
    </div>
</div>

<!-- Firebase SDKs -->
<script src="https://www.gstatic.com/firebasejs/9.23.0/firebase-app-compat.js"></script>
<script src="https://www.gstatic.com/firebasejs/9.23.0/firebase-auth-compat.js"></script>
<script src="https://www.gstatic.com/firebasejs/9.23.0/firebase-firestore-compat.js"></script>

<script>
const firebaseConfig = {
  apiKey: "AIzaSyBOaHzIMdXZHOfgDS56sKKL6NLRT41dBmM",
  authDomain: "it-helpdesk-fyp2.firebaseapp.com",
  projectId: "it-helpdesk-fyp2",
  storageBucket: "it-helpdesk-fyp2.firebasestorage.app",
  messagingSenderId: "168621686870",
  appId: "1:168621686870:web:a3cd6fd0c36b60c0adbbf7",
  measurementId: "G-MVE0EDPWTT"
};
if (!firebase.apps.length) firebase.initializeApp(firebaseConfig);
</script>

<script src="<?php echo e(asset('js/signup.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\Users\darme\FYP2_Admin_laravel_side\resources\views/signup.blade.php ENDPATH**/ ?>