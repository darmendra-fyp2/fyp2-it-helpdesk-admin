<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard – IT Helpdesk</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/dashboard.css')); ?>">
    <style>
        /* ======================= */
        /* Image Modal */
        /* ======================= */
        #imageModal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 30, 0.95);
            justify-content: center;
            align-items: center;
            z-index: 9999;
        }
        #imageModal img {
            max-width: 90%;
            max-height: 90%;
            border-radius: 20px;
            border: 3px solid #00ffff;
            box-shadow: 0 0 40px rgba(0, 255, 255, 0.7);
        }

        /* ======================= */
        /* Ticket Image */
        /* ======================= */
        .ticket-img {
            width: 90px;
            height: 90px;
            object-fit: cover;
            border-radius: 12px;
            border: 2px solid rgba(0, 255, 255, 0.6);
            box-shadow: 0 0 15px rgba(0, 255, 255, 0.5);
            cursor: pointer;
            transition: all 0.3s ease;
        }
        .ticket-img:hover {
            transform: scale(1.15);
            box-shadow: 0 0 30px rgba(0, 255, 255, 0.9);
        }

        /* ======================= */
        /* Chat Icon & Badge */
        /* ======================= */
        .chat-icon-container {
            position: relative;
            display: inline-block;
        }
        .chat-icon {
            width: 42px;
            height: 42px;
            border-radius: 50%;
            padding: 4px;
            background: linear-gradient(135deg, #00bfff, #1e90ff);
            box-shadow: 0 0 12px rgba(30, 144, 255, 0.6);
            transition: all 0.3s ease;
        }
        .chat-icon:hover {
            transform: scale(1.15) rotate(8deg);
            box-shadow: 0 0 24px rgba(30, 144, 255, 0.9);
        }
        .notification-badge {
            position: absolute;
            top: -8px;
            right: -8px;
            background: #ff4d4f;
            color: white;
            font-size: 11px;
            font-weight: bold;
            min-width: 18px;
            height: 18px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            border: 2px solid #000c1f;
            box-shadow: 0 0 8px rgba(255, 77, 79, 0.7);
            transition: all 0.3s ease;
        }
        .notification-badge.hidden {
            display: none;
        }

        /* ======================= */
        /* Status Dropdown */
        /* ======================= */
        .status-select-wrapper {
            position: relative;
            display: inline-block;
            min-width: 160px;
        }
        .status-select {
            appearance: none;
            -webkit-appearance: none;
            -moz-appearance: none;
            width: 100%;
            padding: 10px 36px 10px 14px;
            font-family: 'Oxanium', sans-serif;
            font-size: 14px;
            font-weight: 500;
            background: rgba(0, 70, 140, 0.8);
            color: #00ffff;
            border: 2px solid rgba(0, 255, 255, 0.6);
            border-radius: 12px;
            box-shadow: 0 0 12px rgba(0, 255, 255, 0.3);
            cursor: pointer;
            transition: all 0.3s ease;
        }
        .status-select:focus {
            outline: none;
            border-color: #00ffff;
            box-shadow: 0 0 20px rgba(0, 255, 255, 0.6);
        }
        .status-select:hover {
            border-color: #00ffff;
            box-shadow: 0 4px 12px rgba(0, 255, 255, 0.5);
        }
        .status-select-wrapper::after {
            content: "▼";
            position: absolute;
            top: 50%;
            right: 14px;
            transform: translateY(-50%);
            pointer-events: none;
            color: #00ffff;
            font-size: 12px;
            transition: color 0.3s ease;
        }
        .status-select-wrapper:hover::after {
            color: #ffffff;
        }

        /* Status variations */
        .status-select.pending    { background: rgba(255, 193, 7, 0.35);  color: #ffeb3b; border-color: #ffeb3b; }
        .status-select.in-progress { background: rgba(33, 150, 243, 0.35); color: #64b5f6; border-color: #64b5f6; }
        .status-select.resolved   { background: rgba(76, 175, 80, 0.35);  color: #81c784; border-color: #81c784; }

        /* ======================= */
        /* Table Alignment & Spacing */
        /* ======================= */
        .table-wrapper {
            overflow-x: auto;
        }
        table {
            table-layout: auto;
            width: 100%;
        }
        table th, table td {
            padding: 16px 12px;
            text-align: center;
            vertical-align: middle;
        }
        table th:nth-child(5), table td:nth-child(5) {
            text-align: left;
            max-width: 320px;
            word-break: break-word;
        }
        table td:nth-child(6) { /* Image */
            width: 120px;
            padding: 12px 8px;
        }
        table td:nth-child(8) { /* Chat */
            width: 80px;
            padding: 12px 8px;
        }
        table td:nth-child(7) { /* Created */
            white-space: nowrap;
        }
    </style>
</head>
<body>
    <!-- Image Modal -->
    <div id="imageModal" onclick="closeImageModal()">
        <img id="modalImg" alt="Ticket Image">
    </div>

    <div class="container">
        <div class="dashboard">
            <!-- Header -->
            <div class="dashboard-header">
                <div class="header-left">
                    <h2>Admin Dashboard</h2>
                    <span class="admin-email" id="adminEmail"></span>
                </div>
                <div class="header-right">
                    <button id="logoutBtn" class="danger">Logout</button>
                </div>
            </div>

            <!-- Filters -->
            <div class="filter-bar">
                <select id="filterCategory">
                    <option value="">All Categories</option>
                    <option value="Software">Software</option>
                    <option value="Hardware">Hardware</option>
                    <option value="Network">Network</option>
                    <option value="Others">Others</option>
                </select>

                <select id="filterStatus">
                    <option value="">All Statuses</option>
                    <option value="Pending">Pending</option>
                    <option value="In Progress">In Progress</option>
                    <option value="Resolved">Resolved</option>
                </select>

                <button onclick="applyFilters()">Apply</button>
                <button class="secondary" onclick="clearFilters()">Clear</button>
            </div>

            <!-- Tickets Table -->
            <div class="table-wrapper">
                <table>
                    <thead>
                        <tr>
                            <th>User</th>
                            <th>Title</th>
                            <th>Status</th>
                            <th>Category</th>
                            <th>Description</th>
                            <th>Image</th>
                            <th>Created</th>
                            <th>Chat</th>
                        </tr>
                    </thead>
                    <tbody id="ticketsTableBody"></tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Firebase Scripts -->
    <script src="https://www.gstatic.com/firebasejs/9.23.0/firebase-app-compat.js"></script>
    <script src="https://www.gstatic.com/firebasejs/9.23.0/firebase-auth-compat.js"></script>
    <script src="https://www.gstatic.com/firebasejs/9.23.0/firebase-firestore-compat.js"></script>

    <script>
    const firebaseConfig = {
      apiKey:"AIzaSyBOaHzIMdXZHOfgDS56sKKL6NLRT41dBmM",
      authDomain:"it-helpdesk-fyp2.firebaseapp.com",
      projectId:"it-helpdesk-fyp2",
      storageBucket:"it-helpdesk-fyp2.firebasestorage.app",
      messagingSenderId:"168621686870",
      appId:"1:168621686870:web:a3cd6fd0c36b60c0adbbf7"
    };
    firebase.initializeApp(firebaseConfig);
    const auth = firebase.auth();
    const db = firebase.firestore();

    // Logout
    document.getElementById('logoutBtn').addEventListener('click', () => {
        auth.signOut().then(() => window.location="/login");
    });

    let allTickets = [];
    const ticketsTableBody = document.getElementById('ticketsTableBody');

    // Store unread counts per ticket (updated in real-time)
    const unreadCounts = {};

    function getStatusClass(status) {
        return status.toLowerCase().replace(' ', '-');
    }

    // Real-time listener for unread user messages per ticket
    function startUnreadListener(ticketId, lastReadTimestamp) {
        if (!lastReadTimestamp) return; // No unread if never read

        const messagesQuery = db.collection('tickets').doc(ticketId)
            .collection('messages')
            .where('sender', '==', 'user')
            .orderBy('createdAt');

        messagesQuery.onSnapshot(snapshot => {
            let unread = 0;
            snapshot.forEach(doc => {
                const msgTime = doc.data().createdAt?.toDate();
                if (msgTime && msgTime > lastReadTimestamp) {
                    unread++;
                }
            });
            unreadCounts[ticketId] = unread;
            updateBadge(ticketId, unread);
        });
    }

    // Update badge in the DOM
    function updateBadge(ticketId, unread) {
        const row = Array.from(ticketsTableBody.querySelectorAll('tr')).find(tr => 
            tr.innerHTML.includes(`/admin/tickets/${ticketId}/chat`)
        );
        if (row) {
            const badge = row.querySelector('.notification-badge');
            if (badge) {
                badge.textContent = unread > 99 ? '99+' : unread;
                badge.classList.toggle('hidden', unread === 0);
            }
        }
    }

    function loadTickets(categoryFilter = '', statusFilter = '') {
        let query = db.collection('tickets').orderBy('createdAt', 'desc');

        if(categoryFilter) query = query.where('category', '==', categoryFilter);
        if(statusFilter) query = query.where('status', '==', statusFilter);

        query.onSnapshot(snapshot => {
            allTickets = [];
            ticketsTableBody.innerHTML = '';
            snapshot.forEach(doc => {
                const ticket = doc.data();
                ticket.id = doc.id;
                if(ticket.createdAt?.toDate) ticket.createdAt = ticket.createdAt.toDate();
                allTickets.push(ticket);

                const statusClass = getStatusClass(ticket.status);

                const lastRead = ticket.lastAdminReadTimestamp?.toDate() || null;
                const unreadCount = unreadCounts[ticket.id] || 0;

                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td>${ticket.userEmail || ticket.userId}</td>
                    <td>${ticket.title}</td>
                    <td>
                        <div class="status-select-wrapper">
                            <select class="status-select ${statusClass}" 
                                    onchange="updateStatus('${ticket.id}', this.value)">
                                <option value="Pending" ${ticket.status==='Pending'?'selected':''}>Pending</option>
                                <option value="In Progress" ${ticket.status==='In Progress'?'selected':''}>In Progress</option>
                                <option value="Resolved" ${ticket.status==='Resolved'?'selected':''}>Resolved</option>
                            </select>
                        </div>
                    </td>
                    <td>${ticket.category}</td>
                    <td>${ticket.description}</td>
                    <td>${ticket.imageBase64 ? `<img src="${ticket.imageBase64}" class="ticket-img" onclick="openImageModal('${ticket.imageBase64}')">`:'No Image'}</td>
                    <td>${ticket.createdAt ? ticket.createdAt.toLocaleString() : ''}</td>
                    <td>
                        <a href="/admin/tickets/${ticket.id}/chat" title="Chat with user" class="chat-icon-container">
                            <img src="https://png.pngtree.com/png-clipart/20240730/original/pngtree-stylish-chat-box-icon-design-for-online-chats-png-image_15666122.png" 
                                 class="chat-icon" 
                                 alt="Chat with user">
                            <span class="notification-badge ${unreadCount > 0 ? '' : 'hidden'}">
                                ${unreadCount > 99 ? '99+' : unreadCount}
                            </span>
                        </a>
                    </td>
                `;
                ticketsTableBody.appendChild(tr);

                // Start real-time listener for unread messages
                startUnreadListener(ticket.id, lastRead);
            });
        });
    }

    function updateStatus(id, status){
        db.collection("tickets").doc(id).update({ status });
    }

    function applyFilters() {
        const category = document.getElementById('filterCategory').value;
        const status = document.getElementById('filterStatus').value;
        loadTickets(category, status);
    }

    function clearFilters() {
        document.getElementById('filterCategory').value = '';
        document.getElementById('filterStatus').value = '';
        loadTickets();
    }

    function openImageModal(src){ 
        const modal = document.getElementById('imageModal');
        const img = document.getElementById('modalImg');
        img.src = src; 
        modal.style.display='flex'; 
    }
    function closeImageModal(){ 
        document.getElementById('imageModal').style.display='none'; 
    }

    loadTickets();
    </script>
</body>
</html><?php /**PATH C:\Users\darme\FYP2_Admin_laravel_side\resources\views/dashboard.blade.php ENDPATH**/ ?>