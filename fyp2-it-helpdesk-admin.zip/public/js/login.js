// public/js/login.js

document.addEventListener("DOMContentLoaded", () => {
    const auth = firebase.auth();
    const db = firebase.firestore();

    const loginForm = document.getElementById("loginForm");
    const signupForm = document.getElementById("signupForm");
    const errorDiv = document.getElementById("errorMsg");

    // ===== Signup =====
    if (signupForm) {
        signupForm.addEventListener("submit", async (e) => {
            e.preventDefault();
            errorDiv.textContent = "";

            const name = signupForm.querySelector('input[name="name"]').value.trim();
            const email = signupForm.querySelector('input[name="email"]').value.trim();
            const password = signupForm.querySelector('input[name="password"]').value.trim();

            if (!name || !email || !password) {
                errorDiv.textContent = "All fields are required.";
                return;
            }

            try {
                // 1️⃣ Create user in Firebase Auth
                const userCredential = await auth.createUserWithEmailAndPassword(email, password);
                const user = userCredential.user;

                // 2️⃣ Determine role (admin if email contains "admin")
                const role = email.toLowerCase().includes("admin") ? "admin" : "user";

                // 3️⃣ Save user info in Firestore
                await db.collection("users").doc(user.uid).set({
                    name,
                    email,
                    role,
                    createdAt: firebase.firestore.FieldValue.serverTimestamp()
                });

                // 4️⃣ Automatically login and redirect based on role
                if (role === "admin") window.location.href = "/dashboard";
                else alert("Signed up as regular user. No dashboard yet.");

            } catch (err) {
                errorDiv.textContent = err.message;
            }
        });
    }

    // ===== Login =====
    if (loginForm) {
        loginForm.addEventListener("submit", async (e) => {
            e.preventDefault();
            errorDiv.textContent = "";

            const email = loginForm.querySelector('input[name="email"]').value.trim();
            const password = loginForm.querySelector('input[name="password"]').value.trim();

            if (!email || !password) {
                errorDiv.textContent = "Email and password are required.";
                return;
            }

            try {
                // 1️⃣ Firebase login
                const userCredential = await auth.signInWithEmailAndPassword(email, password);
                const user = userCredential.user;

                // 2️⃣ Fetch Firestore user doc
                const userDoc = await db.collection("users").doc(user.uid).get();
                if (!userDoc.exists) {
                    errorDiv.textContent = "No user data found. Please sign up first.";
                    return;
                }

                // 3️⃣ Check role
                const role = userDoc.data().role;
                if (role === "admin") {
                    window.location.href = "/dashboard"; // Admin dashboard
                } else {
                    alert("Logged in as regular user. No dashboard yet.");
                }

            } catch (err) {
                errorDiv.textContent = err.message;
            }
        });
    }
});
