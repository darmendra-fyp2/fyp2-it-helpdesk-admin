// ---------- Firebase Init ----------
const firebaseConfig = {
    apiKey: "AIzaSyBOaHzIMdXZHOfgDS56sKKL6NLRT41dBmM",
    authDomain: "it-helpdesk-fyp2.firebaseapp.com",
    projectId: "it-helpdesk-fyp2",
    storageBucket: "it-helpdesk-fyp2.firebasestorage.app",
    messagingSenderId: "168621686870",
    appId: "1:168621686870:web:a3cd6fd0c36b60c0adbbf7",
    measurementId: "G-MVE0EDPWTT"
};
firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();
const db = firebase.firestore();

// ---------- Global Variables ----------
let allTickets = [];

// ---------- Auth Check ----------
window.onload = () => {
    auth.onAuthStateChanged(async user => {
        if (!user) return window.location = "/login";

        const userDoc = await db.collection("users").doc(user.uid).get();
        if (!userDoc.exists || userDoc.data().role !== "admin") {
            alert("Access denied. Only admins can view this dashboard.");
            auth.signOut();
            return window.location = "/login";
        }

        document.getElementById("adminEmail").textContent = user.email;
        loadTicketsRealtime();
    });
};

// ---------- Logout ----------
document.getElementById("logoutBtn").addEventListener("click", async () => {
    try {
        await auth.signOut();
        window.location = "/login";
    } catch (err) {
        alert("Logout failed: " + err.message);
    }
});

// ---------- Tickets ----------
function loadTicketsRealtime() {
    db.collection("tickets")
        .orderBy("createdAt", "desc")
        .onSnapshot(snapshot => {
            allTickets = [];
            snapshot.forEach(doc => {
                const t = doc.data();
                t.id = doc.id;
                if (t.createdAt && t.createdAt.toDate) {
                    t.createdAt = t.createdAt.toDate();
                }
                allTickets.push(t);
            });
            renderTickets(allTickets);
        });
}

function renderTickets(tickets) {
    const tbody = document.getElementById("ticketsTableBody");
    tbody.innerHTML = "";

    tickets.forEach(t => {
        const tr = document.createElement("tr");
        tr.innerHTML = `
            <td>${t.userEmail || t.userId}</td>
            <td>${t.title}</td>
            <td>
                <select onchange="updateStatus('${t.id}', this.value)">
                    <option value="Pending" ${t.status === 'Pending' ? 'selected' : ''}>Pending</option>
                    <option value="In Progress" ${t.status === 'In Progress' ? 'selected' : ''}>In Progress</option>
                    <option value="Resolved" ${t.status === 'Resolved' ? 'selected' : ''}>Resolved</option>
                </select>
            </td>
            <td>${t.category}</td>
            <td>${t.description}</td>
            <td>
                ${t.imageBase64 
                    ? `<img src="${t.imageBase64}" class="ticket-img" onclick="openImageModal('${t.imageBase64}')">` 
                    : 'No Image'
                }
            </td>
            <td>${t.createdAt ? t.createdAt.toLocaleString() : ''}</td>
            <td>
                <a href="/admin/tickets/${t.id}/chat" title="Chat with user">
                    <img src="/images/chat-icon.png" alt="Chat" style="width:24px;height:24px;cursor:pointer;">
                </a>
            </td>
        `;
        tbody.appendChild(tr);
    });
}

function updateStatus(id, status) {
    db.collection("tickets").doc(id).update({ status });
}

function applyFilters() {
    const category = document.getElementById("filterCategory").value;
    const status = document.getElementById("filterStatus").value;

    let filtered = allTickets;
    if (category) filtered = filtered.filter(t => t.category === category);
    if (status) filtered = filtered.filter(t => t.status === status);

    renderTickets(filtered);
}

function clearFilters() {
    document.getElementById("filterCategory").value = "";
    document.getElementById("filterStatus").value = "";
    renderTickets(allTickets);
}

// ---------- Image Modal ----------
function openImageModal(base64) {
    document.getElementById("modalImg").src = base64;
    document.getElementById("imageModal").style.display = "flex";
}

function closeImageModal() {
    document.getElementById("imageModal").style.display = "none";
}
