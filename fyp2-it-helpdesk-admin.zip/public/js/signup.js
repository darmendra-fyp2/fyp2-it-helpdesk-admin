document.addEventListener("DOMContentLoaded", () => {
    const signupForm = document.getElementById("signupForm");
    const errorMsg = document.getElementById("errorMsg");

    const auth = firebase.auth();
    const db = firebase.firestore();

    signupForm.addEventListener("submit", async (e) => {
        e.preventDefault();
        errorMsg.innerHTML = "";

        const name = signupForm.name.value.trim();
        const email = signupForm.email.value.trim();
        const password = signupForm.password.value;

        if (!name || !email || !password) {
            errorMsg.innerHTML = "All fields are required.";
            return;
        }

        if (password.length < 6) {
            errorMsg.innerHTML = "Password must be at least 6 characters.";
            return;
        }

        try {
            // Create user in Firebase Auth
            const userCredential = await auth.createUserWithEmailAndPassword(email, password);
            const user = userCredential.user;

            // Determine role (admin if email contains "admin")
            const role = email.toLowerCase().includes("admin") ? "admin" : "user";

            // Save user info in Firestore
            await db.collection("users").doc(user.uid).set({
                name,
                email,
                role,
                createdAt: firebase.firestore.FieldValue.serverTimestamp()
            });

            // Redirect or notify
            if (role === "admin") {
                window.location.href = "/dashboard"; // admin dashboard
            } else {
                alert("Signed up as regular user. Please login.");
                window.location.href = "/login";
            }

        } catch (err) {
            console.error(err);
            errorMsg.innerHTML = err.message;
        }
    });
});
